import Moleculer from "moleculer";
import MC from "@moleculer/channels"
import { ServiceBroker } from "@moleculer/channels/types/src/adapters/base";

export const bye : Moleculer.ServiceSchema = {
    name: "bye",
    actions:{
        greet: ()=> {
            // let broker:ServiceBroker  = this.broker;
            // broker.emit("my.topic.bye",{text:"bye"})
            return `bye from ${"jlsdjflds"}`
        },
        exposed1: ()=>{
            return "from exposed1"
        },
        exposed2: ()=>{
            return "from exposed2"
        }
    },
    // mixin: [MC],
    // settings:{
    //     channels:{
    //         "my.topic.*":{
    //             handler(ctx){
    //                 console.log("this is channel event",ctx)
    //             }
    //         }
    //     }
    // }
    channels:{
        "p1.bye.channel"(ctx:Moleculer.Context){
            console.log("msg in bye channel")
        }
    }
}

export const ByeActions = {
    name: "bye",
    version: "",
    expose : ["exposed1", "exposed2"]
}