import Moleculer, { InfoMetric, InfoMetricSnapshot, Service } from "moleculer";

// import MC from "@moleculer/channels"

export const hello: Moleculer.ServiceSchema = {
    name: 'hello',
    actions: {
        greet: async (ctx) => {
            //@ts-ignore
            await ctx.sendToChannel("p1.test.channel",{},{meta: {b:10}})
            return `hello from ${"lkjsdflksjd"}`;
        },
        expose: () => {
            return "from expose"
        }
    },
    methods: {
        healthCheck(ctx) {
            //@ts-ignore
            this.broker.metrics.set("hello.health-check", 1, { health_check: 0 }, new Date().getTime())
        }
    },
    created() {

        console.log("------------created hello service--------------")
        const health_check = "health_check"
        //@ts-ignore
        this.broker.metrics.register({
            type: "info",
            name: "hello.health-check",
            description: "health check for hello service",
            labelNames: [health_check],
            unit: "unit"
        })
        //@ts-ignore
        this.broker.metrics.set("hello.health-check", 2, { health_check: 0 }, new Date().getTime())
    },
    events: {
        "perform_health_check"(ctx: Moleculer.Context) {
            console.log("performing health check on 'HELLO' service")
            this.healthCheck(ctx)
        }
    },
    channels:{
        "p1.hello.channel":{
            nats:{
                ack_wait: 1 * 1000 * 1000
            },
            group: "hello-1",
            async handler(ctx: Moleculer.Context){
                console.log("message in hello channel", ctx.params)
                await new Promise((res,rej)=>{
                    setTimeout(() => {
                        res(0)
                    }, Math.ceil(Math.random()*5+1)*1000);
                })
                // throw new Error("failing")
                return true
            },
            
        },
        "p1.test.channel":{
            group: "hello-11",
            handler: (ctx:Moleculer.Context) => {
                
                //@ts-ignore
                console.log("ctx from test channel---", ctx.sendToChannel)
                //@ts-ignore
                ctx.sendToChannel("p1.test.channel2")
            }
        },
        "p1.test.channel2":{
            group: "hello-12",
            handler: (ctx:Moleculer.Context) => {
                console.log("ctx from test 2 channel---", ctx)
            }
        }
    }
}

export const helloActions = {
    name: "hello",
    version: "",
    expose: ["expose"]
}