import Moleculer from "moleculer";
import APIMIXIN from 'moleculer-web'


export const apiMixin :Moleculer.ServiceSchema = {
    name: "api",
    mixins: [APIMIXIN],
    settings: {
        port: 3000,
        ip: "0.0.0.0",
        routes: [
            {
                path: "/api",
                whitelist: ["**"]
            }
        ]
    }
}