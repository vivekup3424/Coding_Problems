import Moleculer, { ServiceBroker } from "moleculer";
import { Middleware } from "@moleculer/channels"
import { ChannelHandlerRunStatus, TaskStatus } from "../../example/interface";

export const channelStatusListener = "default.channel.status"
export const deadQueueChannel = "p1.dead.queue"

const channelsHookMiddleware = {
    name: "channel-hook",
    localChannel: (next: any, chan: any) => {
        return async (msg: Moleculer.Context, raw: any) => {

            if (msg.broker.sendToChannel) {
                //@ts-ignore
                msg.sendToChannel = (name: string, params: any, opts: any) => {

                    if (opts?.meta) {
                        msg.meta = { ...msg.meta, ...opts.meta }
                    }

                    return msg.broker.sendToChannel(name, params ?? {}, { msg })
                }
            }

            const sameChannel = `${msg.broker.namespace}.${channelStatusListener}` == chan.name
            const fromDeadQueue = `${msg.broker.namespace}.${deadQueueChannel}` == chan.name

            if (!sameChannel && !fromDeadQueue) {

                //@ts-ignore
                await msg.broker?.sendToChannel(channelStatusListener, <ChannelHandlerRunStatus>{
                    status: TaskStatus.RUNNING,
                    attempt: raw?.di?.deliveryCount,
                    name: chan.name,
                    reqId: msg.requestID,
                    parentRequestId: msg.parentID,
                    msg: msg.params
                })
            }

            try {
                const res = await next(msg, raw);

                if (!sameChannel && !fromDeadQueue) {
                    //@ts-ignore
                    await msg.broker?.sendToChannel(channelStatusListener, <ChannelHandlerRunStatus>{
                        status: TaskStatus.SUCCESS,
                        attempt: raw?.di?.deliveryCount,
                        response: res,
                        name: chan.name,
                        msg: msg.params
                    })
                }
            } catch (err) {
                console.log("error in channel handler---", msg, err)
                throw new Error(err?.toString())
            }
        };
    },

    sendToChannel: (next: any) => {
        return async (channelName: any, payload: any, opts: any) => {

            await next(channelName, payload, opts);

        };
    }
}

const addSendToChannelInActionContext = {
    name: "append-sendtoChannel",
    localAction: (next: any, action: any) => {
        return async (ctx: Moleculer.Context, raw: any) => {
            console.log("from append middleware ", raw)
            if (ctx.broker.sendToChannel) {
                //@ts-ignore
                ctx.sendToChannel = (name: string, params: any, opts: any) => {

                    if (opts?.meta) {
                        ctx.meta = { ...ctx.meta, ...opts.meta }
                    }

                    return ctx.broker.sendToChannel(name, params ?? {}, { ctx })
                }
            }

            return next(ctx)
        }
    },
}

export function createBroker(nodeId: string) {
    const namespace = "testing"
    return new ServiceBroker({
        namespace,
        nodeID: nodeId,
        transporter: {
            type: "NATS",
            options: {
                url: `nats://localhost:4222`,
                token: "nats-test"
            }
        },
        validator: true,
        middlewares: [
            //@ts-ignore
            Middleware({
                adapter: {
                    type: "NATS",
                    //@ts-ignore
                    options: {
                        nats: {
                            connectionOptions: { token: "nats-test" },
                            // streamConfig: {
                            //     name: "default",
                            //     subjects: ["p1.>", "p2.>", "default.>"].map(sub => `${namespace}.${sub}`)
                            // },
                            streamConfig: { // current limitation is that if we change any of these configs, it will try to create new stream instead of updating
                                name: "default",
                                subjects:  ["p1.>", "p2.>", "default.>"].map(sub => `${namespace}.${sub}`),
                                max_age: 120 * 1000 * 1000 * 1000, //Nano seconds
                                max_msgs: 50 // this is too low for prod
                            },
                            consumerOptions: {
                                config: {
                                    deliver_policy: "new",
                                    ack_policy: "explicit",
                                    // max_ack_pending: -1,
                                    ack_wait: 1 * 60 * 60 * 1000 * 1000
                                }
                            },
                            // maxRetries: 3,
                        },
                        maxInFlight: 100000,
                        maxRetries: 5,
                        deadLettering: {
                            enabled: true,
                            queueName: deadQueueChannel,
                            exchangeName: "",
                            exchangeOptions: {},
                            queueOptions: {}
                        }
                    }
                },
                context: true
            }),
            //@ts-ignore
            channelsHookMiddleware,
            //@ts-ignore
            // addSendToChannelInChannelContext,
            //@ts-ignore
            addSendToChannelInActionContext,
        ],
        // registry: {
        // 	strategy: Strategies.RoundRobin
        // }
    })
}