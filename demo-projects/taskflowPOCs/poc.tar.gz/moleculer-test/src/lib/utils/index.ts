export const delay = (d = 0) => new Promise((res,rej)=>{
    setTimeout(() => {
        res(0)
    }, d);
})