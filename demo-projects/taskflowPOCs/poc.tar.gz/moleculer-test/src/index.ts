import { apiMixin } from "./lib/services/api-mixin"
import { hello } from "./lib/services/hello"
import { bye } from "./lib/services/bye"
import { createBroker } from "./lib/broker/broker"

// export const nodeID = process.env.HOSTNAME || "test"
// const nodeID = process.env.HOSTNAME



async function main() {
	const broker = createBroker("node-1")

	broker.createService(apiMixin)
	broker.createService(hello)

	const broker2 = createBroker("node-2")

	broker2.createService(bye)

	await broker.start()
	await broker2.start()

	await broker.call("hello.greet",{},{meta: {a:5},})

}

main()