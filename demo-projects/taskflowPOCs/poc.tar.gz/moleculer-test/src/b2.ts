import { createBroker } from "./lib/broker/broker"

(async()=>{
    const broker = createBroker("b2")

    broker.meta = {
        test: "123"
    }

    await broker.start()

    const res = await broker.call("s1.a1",{},{meta: {
        test: "321",
    }});
    console.log("response from a1", res)
})()