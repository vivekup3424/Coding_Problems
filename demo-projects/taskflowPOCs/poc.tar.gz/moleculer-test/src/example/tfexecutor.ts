import { ChannelHandlerRunStatus, ChannelMessageSchema, TaskFlowTask, TaskType } from "./interface";
import { channelMsgTracker } from "./channelMsgTracker";
import * as uuid from "uuid"
import Moleculer from "moleculer";
import { executeWithRetries } from "./retry";
import { EventEmitter } from "stream";

export enum ExecutorEvents{
    RETRY = "retry",
    ERROR = "error",
    COMPLETE = "complete"
}

class TaskFlowExecutor extends EventEmitter {

    context: Moleculer.Context

    constructor(ctx: Moleculer.Context) {
        super()
        this.context = ctx
    }

    async runTasks(tasks: Array<TaskFlowTask>) {

        const taskPromises = []

        for (const task of tasks) {
            switch (task.type) {
                case TaskType.ACTION:
                    taskPromises.push(this.runActionTask(task))
                    break;
                case TaskType.CHANNEL_EVENT:
                    taskPromises.push(this.runChannelTask(task))
                    break;
                case TaskType.EVENT:
                    taskPromises.push(this.runEventTask(task))
            }
        }

        return Promise.all(taskPromises)

    }

    async runActionTask(task: TaskFlowTask) {

        if (!task.action) {
            this.emit(ExecutorEvents.ERROR, { task, err: "Bad params" })
            return
        }

        const onRetry = async (attempt: number, err: any) => {
            this.emit(ExecutorEvents.RETRY, { attempt, err, task })
        }

        const execution = await executeWithRetries.execute(async () => {
            const actionRes = await this.context.call(
                `${task.action!.serviceVersion ? task.action!.serviceVersion + "." : ""}${task.action!.serviceId}.${task.action!.actionName}`,
                task.params!,
                {
                    retries: task.action!.maxRetires
                })

            return actionRes
        }, {
            onRetry,
            delayMs: 2000,
            maxAttempts: 3
        })

        if (!execution.success) {
            return {
                success: false,
                error: execution.result?.toString()
            }
        }

        this.emit(ExecutorEvents.COMPLETE, {task})

        return execution.result
    }

    async runChannelTask(task: TaskFlowTask) {

        if (!task.channel) {
            this.emit(ExecutorEvents.ERROR, { task, err: "Bad params" })
            return
        }

        const params: ChannelMessageSchema = {
            ...task.params,
            taskflowId: uuid.v4()
        }

        //@ts-ignore
        await this.context.sendToChannel(task.channel.channelName, params)

        let resolve: (val: ChannelHandlerRunStatus) => void

        const promise = new Promise<ChannelHandlerRunStatus>((res, rej) => {
            resolve = res
        })

        const onFinish = (msg: ChannelMessageSchema, res: ChannelHandlerRunStatus) => {
            resolve(res)
        }

        const onRetry = (attempt: number) => {
            this.emit(ExecutorEvents.RETRY, { attempt, task })
        }

        channelMsgTracker.trackMsg(params, onFinish, onRetry)

        const channelRes = await promise

        this.emit(ExecutorEvents.COMPLETE, {task})

        return channelRes.response

    }

    async runEventTask(task: TaskFlowTask) {

        if (!task.event) {
            this.emit(ExecutorEvents.ERROR, { task, err: "Bad params" })
            return
        }

        await this.context.emit(task.event.eventName, task.params)

        this.emit(ExecutorEvents.COMPLETE, {task})

        return true
    }
}

export {
    TaskFlowExecutor
}