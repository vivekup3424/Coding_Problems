import Moleculer from "moleculer";
import { TaskFlowSchema, TaskType } from "./interface";
import { TaskFlowExecutor } from "./tfexecutor";

class TaskflowManager {

    runningTaskFlows: Map<string, TaskFlowSchema>

    constructor() {
        this.runningTaskFlows = new Map()
    }

    async produceTaskFlow(taskflow: TaskFlowSchema, ctx: Moleculer.Context) {
        for (const stage in taskflow) {
            const executor = new TaskFlowExecutor(ctx)

            // executor.on("")

            const responses = await executor.runTasks(taskflow[stage])
            console.log("responses of state ", stage, responses)

            for (let i = 0; i < responses.length; i++) {
                const task = taskflow[stage][i]

                if (task.type == TaskType.EVENT) {
                    continue
                }


                //@ts-ignore
                ctx.meta[task.name] = responses[i]
            }

            console.log("stage 1 finished....")

        }
    }
}

const taskFlowManager = new TaskflowManager()

export {
    taskFlowManager
}