import Moleculer from "moleculer";
import { delay } from "nats";

export const s1: Moleculer.ServiceSchema = {
    name: 's1',
    actions: {
        a1: async (ctx) => {
            
            console.log("a1 api triggered -----------", ctx.params, ctx.meta)

            await delay(2 * 1000)

            await ctx.emit("p1.s1.event1", {})

            // if(Math.random() < .5){
            //     throw new Error("swr")
            // }

            return {
                success: true,
                msg: "from a1 action"
            };
        },
        a2: async (ctx) => {

            console.log("a2 api triggerd -----------", ctx.params)


            return {
                success: true,
                msg: "res from a2"
            }
        }
    },
    created() {

    },
    channels:{
        "p1.s1.channel1":{
            group: "s1-1",
            async handler(ctx: Moleculer.Context){
                
                console.log("triggered channel 1 -----", ctx.params, ctx.meta)

                await delay(2 * 1000)

                // if(Math.random()< .5){
                //     throw new Error("swr")
                // }

                return {
                    success: true,
                    data: "some data from channel"
                }
            },
            
        },
        "p1.s1.channel2":{
            group: "s1-2",
            handler: async (ctx:Moleculer.Context) => {
                
                console.log("triggered channel 2---", ctx.params)

                return true
            }
        }
    },
    events: {
        async "p1.s1.event1"(ctx: Moleculer.Context){
            console.log("triggered event 1 in s1----", ctx.params)

        },
        async "p1.s1.event2"(ctx: Moleculer.Context){
            console.log("triggered event 2 in s1----", ctx.params)

        }
    }
}
