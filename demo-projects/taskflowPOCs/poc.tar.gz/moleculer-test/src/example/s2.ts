import Moleculer from "moleculer";
import { delay } from "nats";

export const s2: Moleculer.ServiceSchema = {
    name: 's2',
    actions: {
        a1: async (ctx) => {
            
            console.log("s2 a1 api triggered -----------", ctx.params)

            await delay(2 * 1000)

            return {
                success: true,
                msg: "s2 from a1"
            };
        },
        a2: async (ctx) => {

            console.log("s2 a2 api triggerd -----------", ctx.params)

            return {
                success: true,
                msg: " s2 res from a2"
            }
        }
    },
    created() {

    },
    channels:{
        "p1.s2.channel1":{
            group: "s2-1",
            async handler(ctx: Moleculer.Context){
                
                console.log("triggered s2 channel 1 -----", ctx.params)

                return true
            },
            
        },
        "p1.s2.channel2":{
            group: "s2-2",
            handler: async (ctx:Moleculer.Context) => {
                
                console.log("triggered s2 channel 2---", ctx.params)

                return true
            }
        }
    },
    events: {
        async "p1.s2.event1"(ctx: Moleculer.Context){
            console.log("triggered s2 event 1 ----", ctx.params)

        },
        async "p1.s2.event2"(ctx: Moleculer.Context){
            console.log("triggered s2 event 2 ----", ctx.params)

        }
    }
}