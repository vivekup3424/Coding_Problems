import Moleculer from "moleculer";
import { channelStatusListener, createBroker } from "../lib/broker/broker";
import { ChannelHandlerRunStatus, TaskFlowSchema, TaskStatus, TaskType } from "./interface";
import { taskFlowManager } from "./tfmanager";
import { delay } from "nats";
import { channelMsgTracker } from "./channelMsgTracker";

(async () => {
    const broker = createBroker("task-flow")

    const taskflow: Moleculer.ServiceSchema = {
        name: 'taskflow',
        actions: {
            produce: async (ctx: Moleculer.Context<TaskFlowSchema>) => {
                await taskFlowManager.produceTaskFlow(ctx.params, ctx)
            }
        },
        channels: {
            "default.channel.status": {
                group: `${broker.namespace}-taskflow`,
                handler: async (ctx: Moleculer.Context) => {
                    // console.log("msg from channel status ", ctx.params)
                    channelMsgTracker.processChannelStates(<ChannelHandlerRunStatus>ctx.params)
                }
            },
            "p1.dead.queue": {
                group: `taskflow-1`,
                handler: async (ctx: Moleculer.Context) => {
                    //@ts-ignore
                    await ctx.sendToChannel(channelStatusListener, <ChannelHandlerRunStatus>{
                        status: TaskStatus.FAILED,
                        msg: ctx.params
                    })
                }
            }
        },
        events: {

        }
    }

    broker.createService(taskflow)
    await broker.start()

    while (true) {
        await broker.call("taskflow.produce", <TaskFlowSchema>{
            stage0: [
                // {
                //     name: "task1",
                //     params: {
                //         a: 3,
                //         b: 4,
                //     },
                //     type: TaskType.ACTION,
                //     action: {
                //         serviceId: "s1",
                //         serviceVersion: "",
                //         actionName: "a1",
                //         maxRetires: 3
                //     }
                // },
                // {
                //     name: "task2",
                //     params: {
                //         x: 2,
                //         y: 3
                //     },
                //     type: TaskType.CHANNEL_EVENT,
                //     channel: {
                //         channelName: "p1.s1.channel1"
                //     }
                // },
                {
                    name: "task3",
                    params: {
                        msg: "hello world"
                    },
                    type: TaskType.EVENT,
                    event: {
                        eventName: "p1.s1.event1"
                    }
                }
            ],
            // stage1: [
            //     {
            //         name: "task4",
            //         params: {
            //             a: 3,
            //             b: 4,
            //         },
            //         type: TaskType.ACTION,
            //         action: {
            //             serviceId: "s1",
            //             serviceVersion: "",
            //             actionName: "a1",
            //             maxRetires: 3
            //         }
            //     },
            //     {
            //         name: "task5",
            //         params: {
            //             x: 2,
            //             y: 3
            //         },
            //         type: TaskType.CHANNEL_EVENT,
            //         channel: {
            //             channelName: "p1.s1.channel1"
            //         }
            //     }
            // ]
        })
        break
        console.log("will try again in 4 sec")
        await delay(4 * 1000)
    }
    // broker.emit("p1.s1.event1",{})
})()