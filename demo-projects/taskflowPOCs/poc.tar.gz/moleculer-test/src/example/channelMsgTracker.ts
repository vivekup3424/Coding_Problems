import { ChannelHandlerRunStatus, ChannelMessageSchema, TaskFlowTask, TaskStatus } from "./interface"

class ChannelMsgTracker{

    msgs: Map<string,{
        msg: ChannelMessageSchema,
        onFinish: (msg: ChannelMessageSchema, res: ChannelHandlerRunStatus) => void,
        onRetry: (attempt: number, err?: unknown) => void,
        status?: ChannelHandlerRunStatus
    }>

    constructor(){
        this.msgs = new Map()
    }

    trackMsg(msg: ChannelMessageSchema, onFinish: (msg: ChannelMessageSchema, res: ChannelHandlerRunStatus) => void, onRetry: (attempt: number, err?: unknown) => void){

        if(!msg.taskflowId){
            throw new Error("Cannot track this message")
        }

        this.msgs.set(msg.taskflowId, {
            msg,
            onFinish,
            onRetry
        })
    }

    clearMsgFromTracking(msg: ChannelMessageSchema){
        this.msgs.delete(msg.taskflowId)
    }

    processChannelStates(msgState: ChannelHandlerRunStatus){
        const msgInfo = this.msgs.get(msgState.msg?.taskflowId)

        if(!msgInfo){
            return;
        }

        if(!msgInfo.status){
            msgInfo.status = msgState
            return
        }

        if(msgState.status == TaskStatus.SUCCESS || msgState.status == TaskStatus.FAILED){
            msgInfo.onFinish(msgInfo.msg, msgState)
            this.clearMsgFromTracking(msgInfo.msg)
            return
        }

        if(msgState.attempt != msgInfo.status.attempt){
            msgInfo.onRetry(msgState.attempt)
        }

        msgInfo.status = msgState
    }
}

const channelMsgTracker = new ChannelMsgTracker()

export{ 
    channelMsgTracker
}