export interface RetryOptions {
    maxAttempts: number;
    delayMs: number;
    backoff?: {
        type: 'exponential' | 'linear';
        factor: number;
    };
    onRetry?: (attempt: number, error: unknown) => Promise<void> | void;
}

export interface RetryResult<T> {
    success: boolean;
    result?: T;
    error?: {
        message: string;
        code: number;
    };
    attempts: number;
}

const DEFAULT_MAX_RETIRES = 3
const DEFAULT_RETRY_DELAY = 10 * 1000

class RetryExecutor {
    constructor() {}

    async execute<T>(
        operation: () => Promise<T>,
        options: RetryOptions = {delayMs: DEFAULT_RETRY_DELAY, maxAttempts: DEFAULT_MAX_RETIRES}
    ): Promise<RetryResult<T>> {
        let attempts = 0;
        let currentDelay = options.delayMs;

        while (attempts < options.maxAttempts) {
            try {
                attempts++;
                const result = await operation();
                
                return {
                    success: true,
                    result,
                    attempts
                };
            } catch (error: any) {
                const shouldRetry = attempts < options.maxAttempts;
                
                if (options.onRetry) {
                    await options.onRetry(attempts, error);
                }

                if (!shouldRetry) {
                    return {
                        success: false,
                        error: {
                            message: (error instanceof Error ? error.message : error?.toString()) || "Operation Failed",
                            code: 500
                        },
                        attempts
                    };
                }

                await this.delay(currentDelay);
                currentDelay = this.calculateNextDelay(currentDelay, options);
            }
        }

        return {
            success: false,
            error: {
                message: `Failed after ${attempts} attempts`,
                code: 500
            },
            attempts
        };
    }

    private calculateNextDelay(currentDelay: number, options: RetryOptions): number {
        if (!options.backoff) return currentDelay;

        switch (options.backoff.type) {
            case 'exponential':
                return currentDelay * options.backoff.factor;
            case 'linear':
                return currentDelay + (options.delayMs * options.backoff.factor);
            default:
                return currentDelay;
        }
    }

    private delay(ms: number): Promise<void> {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

export const executeWithRetries = new RetryExecutor()

// Usage example:
/*
const retryExecutor = new RetryExecutor(logger);

const result = await retryExecutor.execute(
    async () => {
        // Your operation here
        return await someAsyncOperation();
    },
    {
        maxAttempts: 3,
        delayMs: 1000,
        backoff: {
            type: 'exponential',
            factor: 2
        },
        onRetry: (attempt, error) => {
            console.log(`Retry attempt ${attempt} failed: ${error}`);
        }
    }
);

if (result.success) {
    console.log('Operation succeeded:', result.result);
} else {
    console.error('Operation failed:', result.error);
}
*/