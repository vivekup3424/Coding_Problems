enum TaskStatus{
    WAITING = "WAITING",
    QUEUED = "QUEUED",
    RUNNING = "RUNNING",
    SUCCESS = "SUCCESS",
    FAILED = "FAILED"
}

enum TaskType{
    ACTION = "ACTION",
    CHANNEL_EVENT = "CHANNEL",
    EVENT = "EVENT"
}

interface TaskStatusInfo<TaskRes = unknown>{
    status: TaskStatus,
    attempt: number,
    response?: TaskRes
}

interface ChannelHandlerRunStatus<ChannelParams = any,ChannelHandlerRes = unknown>{
    status: TaskStatus,
    name: string,
    attempt: number,
    response?: ChannelHandlerRes,
    msg: ChannelParams,
    reqId: string,
    parentRequestId: string
}

interface ActionTypeTask{
    serviceId: string,
    serviceVersion: string,
    actionName: string,
    maxRetires?: number
}

interface EventTypeTask{
    eventName: string
}

interface ChannelTypeTask{
    channelName: string
    maxRetries?: number
}

interface TaskFlowTask<ReqData = {[key: string]: any}>{
    name: string,
    type: TaskType
    params: ReqData
    action?: ActionTypeTask,
    event?: EventTypeTask,
    channel?: ChannelTypeTask
}

interface TaskFlowSchema{
    [stage: string]: Array<TaskFlowTask>
}

interface ChannelMessageSchema{
    taskflowId: string,
    [key: string]: any
}

export type {
    ChannelHandlerRunStatus,
    TaskStatusInfo,
    TaskFlowSchema,
    TaskFlowTask,
    ChannelMessageSchema
}

export {
    TaskType,
    TaskStatus
}