import { createBroker } from "../lib/broker/broker"
import { s1 } from "./s1"
import { s2 } from "./s2"

(async()=>{
    const broker = createBroker("new-1")
    broker.createService(s1)
    broker.createService(s2)
    await broker.start()
})()