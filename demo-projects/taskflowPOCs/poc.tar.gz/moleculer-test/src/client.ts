import Moleculer from "moleculer"
import { createBroker } from "./lib/broker/broker"
import { delay } from "./lib/utils"

export const nodeID = process.env.HOSTNAME
// const nodeID = process.env.HOSTNAME

async function main() {
    const broker = createBroker("node-3")

    broker.createService({
        name: "xyz-1",
        channels: {
            async "p1.taskflow.execute"(ctx: Moleculer.Context) {
                console.log("fact change --", ctx.params, ctx.requestID)
                await delay(2000)
                await broker.sendToChannel("p1.task.status",{ "id": "12345" , state: "queued"})
                const res = await broker.sendToChannel("p1.hello.channel", { "id": "12345" })
                console.log("send res -", res)

            },
            "p1.dead.queue":{
                async handler(ctx:Moleculer.Context,raw: any) {
                    // await broker.sendToChannel("p1.task.status",{ "id": "12345" , state: "failed"})
                    console.log("marking this req as dead --", ctx.params, raw)
                },
                group: "xyz-1234"
            },
            "p1.task.status": {
                async handler(ctx: Moleculer.Context){
                    console.log("task status --",ctx.params)
                },
                group: "xyz-12345"
            }
        }
    })

    await broker.start()

    await broker.sendToChannel("p1.taskflow.execute",{})
}

main()