import { createBroker } from "./lib/broker/broker"

(async()=>{
    const broker = createBroker("b1")

    broker.createService({
        name: "s1",
        actions: {
            async a1(ctx){
                console.log("called s1 a1 --", ctx.broker.meta)
                console.log("called s1 a1 --", ctx)
                const res = await broker.call("s2.a1",{},{meta:{a: 5}})
                console.log("res from s2 a2",res)
                return true
            }
        }
    })
    broker.createService({
        name: "s2",
        actions: {
            async a1(ctx){
                console.log("called s2 a1 --", ctx.broker.meta)
                console.log("called s2 a1 --", ctx)
                return true
            }
        }
    })

    broker.meta = {
        test: "123"
    }

    await broker.start()

    // await broker.call("s1.a1",{},{meta:{b:4}})
})()