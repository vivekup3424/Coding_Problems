import {AckPolicy, connect, DeliverPolicy} from "nats"

(async()=>{
    const nc = await connect({servers: "nats://localhost:4222",token: "nats-test"})
    console.log("server", nc.getServer())
    
    const jsm = await nc.jetstreamManager()

    const streams = jsm.streams.list()

    for await (const stream of streams){
        console.log("stream -", stream.config.name)
    }
    const js = nc.jetstream()
    const consumer = await jsm.consumers.add("default",{
        ack_policy: AckPolicy.Explicit,
        ack_wait: 5 * 1000 * 1000,
        deliver_policy: DeliverPolicy.New,
        durable_name: "test-u",
        filter_subject: "p1.hello.channel",
    })

    console.log("consumer -", consumer)

    const c = await js.consumers.get("default","test-u")
    for await (const msg of await c.consume()){
        console.log("msg", msg.data.toString(), msg.info)
        await new Promise((res,rej)=>{
            setTimeout(() => {
                res(0)
            }, 2000);
        })
        // continue
        msg.ack()
    }
})()