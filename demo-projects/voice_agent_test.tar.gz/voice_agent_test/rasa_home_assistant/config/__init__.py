"""
Configuration module for Smart Home Assistant
"""

from .constants import *
